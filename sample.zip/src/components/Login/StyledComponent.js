import styled from "styled-components";

export const Heading=styled.h1`
color:blue;`

export const Button1=styled.button`
background:orange;
&:hover {
    background:red;
  }`
